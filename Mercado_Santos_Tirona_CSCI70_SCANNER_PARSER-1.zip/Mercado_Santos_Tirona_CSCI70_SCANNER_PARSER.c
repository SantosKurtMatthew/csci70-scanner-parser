/*
Token list and Implementation status
1. Identifier
2. Number
DONE*   3. String -- DOES NOT HANDLE NEWLINES YET
DONE    4. Assign: :=
DONE    5. Semicolon: ;
DONE    6. Colon: :
DONE    7. Comma: ,
DONE    8. LeftParen: (
DONE    9. RightParen: )
DONE    10. Plus: +
DONE    11. Minus: -
DONE    12. Multiply: *
DONE    13. Divide: /
DONE    14. Raise: **
DONE    15. LessThan: <
DONE    16. Equal: =
DONE    17. GreaterThan: >
DONE    18. LTEqual: <=
DONE    19. GTEqual: >=
DONE    20. NotEqual: !=
DONE    21. EndofFile
DONE    (Addtl) Commment
*/

/*
Parser Production Status

TODO:   add proper success/failure statements to parser functions,
        replace nextToken with the required getToken() function,
        test everything

DONE  1. Prg
DONE  2. Blk
DONE  3. Stm
DONE  4. Argfollow
DONE  5. Arg
DONE  6. Iffollow
DONE  7. Exp
DONE  8. Trmfollow
DONE  9. Trm
DONE  10. Facfollow
DONE  11. Fac
DONE  12. Litfollow
DONE  13. Lit
DONE  14. Val
DONE  15. Cnd
DONE  16. Rel
*/

#include <stdio.h>
#include <ctype.h>
#include <dirent.h>
#include <string.h>

int Prg(), Blk(), Stm(), Argfollow(), Arg(), Iffollow(), Exp(), Trmfollow(), Trm(),
    Facfollow(), Fac(), Litfollow(), Lit(), Val(), Cnd(), Rel();

char* nextToken;
char* currentScanFile;
FILE *parse_Output;

int finalSuccess = 1;
int symbolSuccess = 1;

char *gettoken (char *fileName) {
    // printf("file: %s\n", fileName);
    static FILE *parseInput = NULL;
    static char token[256];
    static char parseFileName[256];
    char line[256];

    // check if given file is different than previously opened file, close previous if yes
    if (parseInput != NULL && strcmp(parseFileName, fileName) != 0) {
        fclose(parseInput);
        parseInput = NULL;
    }

    // open file if not opened yet
    if (parseInput == NULL) 
    {
        parseInput = fopen(fileName, "r");  
        if (parseInput == NULL)
            return NULL;

        strcpy(parseFileName, fileName);
    }

    // close upon end of file
    if (fgets(line, sizeof(line), parseInput) == NULL) {   

        fclose(parseInput);
        parseInput = NULL;                          
        return NULL;
    }

    

    line[strcspn(line, "\n")] = '\0';          // strip newline

    size_t len = strlen(line);
    size_t typeLen = (len < 31) ? len : 31;
    memcpy(token, line, typeLen);              // take only token from line (first 31 columns)
    token[typeLen] = '\0';
    for (int i = (int)typeLen - 1; i >= 0 && token[i] == ' '; i--)
        token[i] = '\0';                       // remove padding (extra spaces after token)

    nextToken = token;
    // printf("token: %s\n", nextToken);
    return token;
}

void readFile(char *fileName) { // function to read each individual input text file
    FILE *input = fopen(fileName, "r"); 
    
    char outputName[256] = "";
    char* current = fileName;   
    char* found;

    while ((found = strstr(current, "input")) != NULL) { // replace all instances of input with output
        strncat(outputName, current, found - current);
        strcat(outputName, "output_scan");
        current = found + strlen("input");
    }
    strcat(outputName, current);

    FILE *output = fopen(outputName, "w");


    char ch;
    char State = 'A';
    char identifier[256] = "";
    size_t identifierLength = 0;

    while ((ch = fgetc(input)) != EOF) { // read file character by character
        void end() // function to end a token, switch back to starting state (A)
        {
            fprintf(output, "\n");
            State = 'A';
        }

        char *keywordCheck(char* identifier) // check if identifier is a keyword, return the proper token
        {
            if (strcmp(identifier, "PRINT") == 0) return "Print";
            else if (strcmp(identifier, "IF") == 0) return "If";
            else if (strcmp(identifier, "ELSE") == 0) return "Else";
            else if (strcmp(identifier, "ENDIF") == 0) return "Endif";
            else if (strcmp(identifier, "SQRT") == 0) return "Sqrt";
            else if (strcmp(identifier, "AND") == 0) return "And";
            else if (strcmp(identifier, "OR") == 0) return "Or";
            else if (strcmp(identifier, "NOT") == 0) return "Not";
            else return NULL;
        }


        if (isspace(ch) && State == 'A') {
            continue;
        }
        switch(State) {
            case 'A': // start state
                if (isdigit(ch)) { // go to state B if next character is a digit
                    State = 'B';
                    fprintf(output, "%-31s%c", "Number", ch);
                }

                // START OF TOKENS W/O PUSHBACK
                else if (ch == '+') { // create PLUS token if next character is +
                    fprintf(output, "%-31s%c", "Plus", ch);
                    end();
                }

                else if (ch == '-') { // create MINUS token if next character is -
                    fprintf(output, "%-31s%c", "Minus", ch);
                    end();
                }

                else if (ch == ';') { // create SEMICOLON token if next character is ;
                    fprintf(output, "%-31s%c", "Semicolon", ch);
                    end();
                }

                else if (ch == ',') { // create COMMA token if next character is ,
                    fprintf(output, "%-31s%c", "Comma", ch);
                    end();
                }

                else if (ch == '(') { // create LeftParen token if next character is (
                    fprintf(output, "%-31s%c", "LeftParen", ch);
                    end();
                }

                else if (ch == ')') { // create RightParen token if next character is )
                    fprintf(output, "%-31s%c", "RightParen", ch);
                    end();
                }

                else if (ch == '=') { // create Equal token if next character is =
                    fprintf(output, "%-31s%c", "Equal", ch);
                    end();
                }


                // TOKENS W/ PUSHBACK
                else if (ch == '*') { // go to state C if next character is *
                    State = 'C';
                }

                else if (ch == '/') { // go to state D if next character is /
                    State = 'D';
                }

                else if (ch == ':') { // go to state E if next character is :
                    State = 'E';
                }
                
                else if (ch == '<') { // go to state F if next character is <
                    State = 'F';
                }

                else if (ch == '>') { // go to state G if next character is >
                    State = 'G';
                }

                else if (ch == '!') { // go to state H if next character is !
                    State = 'H';
                }

                // IDENTIFIER
                else if (isalpha(ch) != 0 || ch == '_') { // go to state I if next character is a letter or underscore (starting an identifier)
                    State = 'I';
                    identifier[identifierLength++] = ch;
                    identifier[identifierLength] = '\0';
                }

                // STRING
                else if (ch == '\"') { // go to state J if next character is " (starting a string)
                    State = 'J';
                    fprintf(output, "%-31s%c", "String", ch);
                }

                // ERROR STATE
                else { // error if other characters
                    fprintf(output, "Lexical Error reading character \"%c\"\n", ch);
                    State = 'S';
                }

                break;

            // STATE B was moved down because there are many states needed for the NUM token

            case 'C': // state for creating Multiply/Raise token 
                if (ch == '*') { // if * again, thats a RAISE token
                    fprintf(output, "%-31s%s", "Raise", "**");
                    end();
                }

                else { // anything else terminates as a MULTIPLY token
                    ungetc(ch, input);
                    fprintf(output, "%-31s%c", "Multiply", '*');
                    end();
                }
                State = 'A';
                break;

            case 'D': // state for creating Divide/Comment
                if (ch == '/') { // if / again, thats a COMMENT token
                    State = 'P';
                }

                else { // anything else terminates as a DIVIDE token
                    ungetc(ch, input);
                    fprintf(output, "%-31s%c", "Divide", '/');
                    end();
                    State = 'A';
                }
                break;
            
            case 'E':
                if (ch == '=') { 
                    fprintf(output, "%-31s%s", "Assign", ":="); // end ASSIGN token if '=' is found
                    end();
                }
                else { // anything else terminates as a COLON token
                    ungetc(ch, input);
                    fprintf(output, "%-31s%c", "Colon", ':');
                    end();
                }

                break;

            case 'F': // state for creating LTEqual/LessThan tokens
                if (ch == '=') { // if <= thats LTEqual token
                    fprintf(output, "%-31s%s", "LTEqual", "<=");
                    end();
                }

                else { // anything else terminates as a LessThan token
                    ungetc(ch, input);
                    fprintf(output, "%-31s%c", "LessThan", '<');
                    end();
                }
                State = 'A';
                break;

            case 'G': // state for creating GTEqual/GreaterThan tokens
                if (ch == '=') { // if <= thats LTEqual token
                    fprintf(output, "%-31s%s", "GTEqual", ">=");
                    end();
                }

                else { // anything else terminates as a GreaterThan token
                    ungetc(ch, input);
                    fprintf(output, "%-31s%c", "GreaterThan", '>');
                    end();
                }
                State = 'A';
                break;
            
            case 'H': // state for creating NotEqual token
                if (ch == '=') { // if != thats NotEqual token
                    fprintf(output, "%-31s%s", "NotEqual", "!=");
                    end();
                }

                else {
                    fprintf(output, "Lexical Error reading character \"%c\"\n", ch); // go to state S if '=' not found
                    State = 'S';
                }
                break;

            case 'I': // state for creating Identifier token
                char* token = keywordCheck(identifier);
                if (token != NULL)
                {
                    fprintf(output, "%-31s%s", token, identifier);
                    ungetc(ch, input);
                    identifier[0] = '\0';
                    identifierLength = 0;
                    end();
                }
    
                else if (isalpha(ch) != 0 || isdigit(ch) != 0 || ch == '_'){ // checks if the character is a number, letter, or underscore
                    State = 'I';
                    identifier[identifierLength++] = ch;
                    identifier[identifierLength] = '\0';
                }

                else{
                    char* token = keywordCheck(identifier);
                    if (token != NULL)
                    {
                        fprintf(output, "%-31s%s", token, identifier);
                    }

                    else 
                    {
                        fprintf(output, "%-31s%s", "Identifier", identifier);
                    }
                    ungetc(ch, input);
                    identifier[0] = '\0';
                    identifierLength = 0;
                    end();
                }
                break;

            case 'J': // state for creating String token
                if (ch == '\"'){ // checks if the string is closed, otherwise continue adding to it
                    fprintf(output, "%c", ch);
                    end();
                }
                else if (ch == '\n'){ // checks if new line before string could be closedd
                    fprintf(output, "\nLexical Error reading character \"\\n\"\n"); // go to state S if yes
                    State = 'S';
                }
                else {
                    State = 'J';
                    fprintf(output, "%c", ch);
                }
                break;

            case 'B': // state for creating Whole Numbers (part of NUM token)
                if (isdigit(ch)) { // continue adding to NUM if next character is digit
                    State = 'B';
                    fprintf(output, "%c", ch);
                }
                else if (ch == '.'){
                    State = 'K';
                    fprintf(output, "%c", ch);
                }
                else if (ch == 'E' || ch == 'e'){
                    State = 'M';
                    fprintf(output, "%c", ch);
                }
                else { // end NUM otherwise
                    ungetc(ch, input);
                    end();
                }
                break;

            case 'K':
                if (isdigit(ch)) {
                    State = 'L';
                    fprintf(output, "%c", ch);
                }
                else{
                    fprintf(output, "\nLexical Error reading character \"%c\"\n", ch); // go to state S if number ends on a .
                    State = 'S';
                }
                break;

            case 'L': // Functionally state B but cannot take .
                if (isdigit(ch)) { // continue adding to NUM if next character is digit
                    State = 'L';
                    fprintf(output, "%c", ch);
                }
                else if (ch == 'E' || ch == 'e'){
                    State = 'M';
                    fprintf(output, "%c", ch);
                }
                else { // end NUM otherwise
                    ungetc(ch, input);
                    end();
                }
                break;
            
            case 'M': // state after E/e in the exponent
                if (ch == '+' || ch == '-'){
                    State = 'N';
                    fprintf(output, "%c", ch);
                }
                else if (isdigit(ch)){
                    State = 'O';
                    fprintf(output, "%c", ch);
                }
                else{
                    fprintf(output, "\nLexical Error reading character \"%c\"\n", ch); // go to state S if number ends on a .
                    State = 'S';
                }
                break;
            
            case 'N': // state to check that the char after the +/- in state M is a number
                if (isdigit(ch)){
                    State = 'O';
                    fprintf(output, "%c", ch);
                }
                else{
                    fprintf(output, "\nLexical Error reading character \"%c\"\n", ch); // go to state S if number ends on a .
                    State = 'S';
                }
                break;
            
            case 'O': // keep getting numbers to complete the exponent
                if (isdigit(ch)){
                    State = 'O';
                    fprintf(output, "%c", ch);
                }
                else { // end NUM otherwise
                    ungetc(ch, input);
                    end();
                }
                break;
            
            case 'P': // ignore all text while comment is ongoing
                if (ch == '\n')
                {
                    State = 'A';
                }
                

            case 'S': // state that handles errors, stop output
                break;
        }
    }
    fprintf(output, "%-31s\n", "EndofFile");

    fclose(input);
    fclose(output);
}

// function to set currentScanFile to output_scan filename based on an input

void parseFile(char *fileName){
    char scanFile[256] = "";
    char outputName[256] = "";
    char* current = fileName;   
    char* found;

    while ((found = strstr(current, "input")) != NULL) { // replace all instances of input with output
        // generate the filename of the output_scan file to be read for tokens
        strncat(scanFile, current, found - current);
        strcat(scanFile, "output_scan");

        // generate the filename of the output_parse file
        strncat(outputName, current, found - current);
        strcat(outputName, "output_parse");
        current = found + strlen("input");
    }
    strcat(scanFile, current);
    currentScanFile = scanFile;

    // Generate the complete filename of the output_parse file
    strcat(outputName, current);
    
    // Open the output file and start parsing
    parse_Output = fopen(outputName, "w");

    gettoken(currentScanFile);
    Prg(fileName);

    // Close the file after parsing
    fclose(parse_Output);
    
}


int main()
{
    struct dirent *de;
    DIR *folder = opendir("."); // open source folder

    while ((de = readdir(folder)) != NULL) { // check all files for text files with input in the name
        char *suffix = strrchr(de->d_name, '.');

        if (strstr(de->d_name, "input") != NULL && suffix != NULL && strcmp(suffix, ".txt") == 0) {
            readFile(de->d_name); // scan each valid file
            parseFile(de->d_name); // parse the scanned files
            
        }
    }

    closedir(folder);    
    return 0;
}

// Prg production
// Takes the input filename in order to write the valid SimpCalc program statement
int Prg(char *fileName)
{
    // -> Blk EndofFile
    if (Blk())
    {
        if (strcmp(nextToken, "EndofFile") == 0 && finalSuccess == 1)
        {
            fprintf(parse_Output, "%s is a valid SimpCalc program\n", fileName);
            return 1;
        }
        else
        {   
            return 0;
        }
    }
    else
    {
        return 0;
    }
}

// Blk production
int Blk()
{
    if (Stm()) // -> Stm Blk
    {
        if (Blk())
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    else    // epsilon
    {
        return 1;
    }
}


// Stm production
int Stm()
{
    if (strcmp(nextToken, "Identifier") == 0) // -> Identifier := Exp;
    {
        gettoken(currentScanFile);
    
        if (strcmp(nextToken, "Assign") == 0)
        {
            gettoken(currentScanFile);

            if (Exp())
            {
                if (strcmp(nextToken, "Semicolon") == 0)
                {
                    fprintf(parse_Output, "Assignment Statement Recognized\n");

                    gettoken(currentScanFile);
                    return 1;
                }
                else
                {
                    fprintf(parse_Output, "Invalid Statement\n");
                    return 0;
                }
            }
            else
            {
                return 0;
            }
        }
        else
        {
            fprintf(parse_Output, "Invalid Statement\n");
            return 0;
        }
    }
    else if (strcmp(nextToken, "Print") == 0) // -> PRINT(Arg Argfollow);
    {
        gettoken(currentScanFile);
        if (strcmp(nextToken, "LeftParen") == 0)
        {
            gettoken(currentScanFile);

            if (Arg())
            {
                if (Argfollow())
                {
                    if (strcmp(nextToken, "RightParen") == 0)
                    {
                        gettoken(currentScanFile);

                        if (strcmp(nextToken, "Semicolon") == 0)
                        {
                            fprintf(parse_Output, "Print Statement Recognized\n");
                            gettoken(currentScanFile);
                            return 1;
                        }
                    }
                    else
                    {
                        fprintf(parse_Output, "Invalid Statement\n");
                        return 0;
                    }
                }
                else
                {
                    return 0;
                }
            }
            else
            {
                return 0;
            }
        }
        else
        {
            fprintf(parse_Output, "Invalid Statement\n");
            return 0;
        }
    }
    else if (strcmp(nextToken, "If") == 0) // -> IF Cnd : Blk Iffollow
    {
        fprintf(parse_Output, "If Statement Begins\n");
        gettoken(currentScanFile);

        if (Cnd())
        {
            if (strcmp(nextToken, "Colon") == 0)
            {
                gettoken(currentScanFile);
                
                if (Blk() && symbolSuccess == 1)
                {
                    if (Iffollow())
                    {
                        return 1;
                    }
                    else
                    {
                        return 0;
                    }
                }
                else
                {
                    return 0;
                }
            }
            else
            {
                // Invalid Statement
                fprintf(parse_Output, "Invalid Statement\n");
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
    else
    {
        return 0;
    }
}

// Argfollow production
int Argfollow()
{
    if (strcmp(nextToken, "Comma") == 0) // -> , Arg Argfollow
    {
        gettoken(currentScanFile);

        if (Arg())
        {
            if(Argfollow())
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
    else    // epsilon
    {
        return 1;
    }
}

// Arg production
int Arg()
{

    if (strcmp(nextToken, "String") == 0) // -> String
    {
        gettoken(currentScanFile);
        return 1;
    }
    else if (Exp()) // -> Exp
    {
        return 1;
    }
    else
    {   
        return 0;
    }
}

// Iffollow production
int Iffollow()
{

    if (strcmp(nextToken, "Endif") == 0) // -> ENDIF;
    {
        gettoken(currentScanFile);

        if (strcmp(nextToken, "Semicolon") == 0)
        {

            fprintf(parse_Output, "If Statement Ends\n");
            gettoken(currentScanFile);
            return 1;
        }
        else
        {
            symbolSuccess = 0;
            fprintf(parse_Output, "Symbol Expected\n");
            return 0;
        }
    }
    else if (strcmp(nextToken, "Else") == 0) // -> ELSE Blk ENDIF;
    {
        gettoken(currentScanFile);

        if (Blk() && symbolSuccess == 1)
        {
            if (strcmp(nextToken, "Endif") == 0)
            {
                gettoken(currentScanFile);

                if (strcmp(nextToken, "Semicolon") == 0)
                {
                    fprintf(parse_Output, "If Statement Ends\n");
                    gettoken(currentScanFile);
                    return 1;
                }
                else
                {
                    finalSuccess = 0;
                    fprintf(parse_Output, "Incomplete If Statement\n");
                    return 0;
                }
            }
            else
            {
                finalSuccess = 0;
                fprintf(parse_Output, "Incomplete If Statement\n");
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
    else
    {
        finalSuccess = 0;
        fprintf(parse_Output, "Incomplete If Statement\n");
        return 0;
    }
}

// Exp production
int Exp()
{
    if (Trm()) // -> Trm Trmfollow
    {
        if (Trmfollow())
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    else
    {
        return 0;
    }
}

// Trmfollow production
int Trmfollow()
{   
    if (strcmp(nextToken, "Plus") == 0) // -> + Trm Trmfollow
    {
        gettoken(currentScanFile);
        if (Trm())
        {
            if (Trmfollow())
            {
                return 1;
            }
            else 
            {
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
    else if (strcmp(nextToken, "Minus") == 0) // -> - Trm Trmfollow
    {
        gettoken(currentScanFile);
        if (Trm())
        {
            if (Trmfollow())
            {
                return 1;
            }
            else 
            {
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
    else    // epsilon
    {
        return 1;
    }
}

// Trm production
int Trm()
{
    if (Fac()) // -> Fac Facfollow
    {
        if (Facfollow())
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    else
    {
        return 0;
    }
}

// Facfollow production
int Facfollow()
{
    if (strcmp(nextToken, "Multiply") == 0) // -> * Fac Facfollow
    {
        gettoken(currentScanFile);
        if (Fac())
        {
            if (Facfollow())
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }
    else if (strcmp(nextToken, "Divide") == 0) // -> / Fac Facfollow
    {
        gettoken(currentScanFile);
        if (Fac())
        {
            if (Facfollow())
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }
    else    // epsilon
    {
        return 1;
    }
}

// Fac production
int Fac()
{
    if (Lit()) // -> Lit Litfollow
    {
        if (Litfollow())
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    else
    {
        return 0;
    }
}

// Litfollow production
int Litfollow()
{
    if (strcmp(nextToken, "Raise") == 0) // -> ** Lit Litfollow
    {
        gettoken(currentScanFile);
        if (Lit())
        {
            if (Litfollow())
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
    else    // epsilon
    {
        return 1;
    }
}

// Lit production
int Lit()
{
    if (strcmp(nextToken, "Minus") == 0) // -> - Val
    {
        gettoken(currentScanFile);
        if (Val())
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    else if (Val()) // -> Val
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

// Val production
int Val()
{
    if (strcmp(nextToken, "Identifier") == 0) // Identifier
    {
        gettoken(currentScanFile);
        return 1;
    }
    else if (strcmp(nextToken, "Number") == 0) // Number
    {
        gettoken(currentScanFile);
        return 1;
    }
    else if (strcmp(nextToken, "Sqrt") == 0) // SQRT(EXP)
    {
        gettoken(currentScanFile);

        if (strcmp(nextToken, "LeftParen") == 0) 
        {
            gettoken(currentScanFile);

            if (Exp())
            {
                if (strcmp(nextToken, "RightParen") == 0)
                {
                    gettoken(currentScanFile);
                    return 1;
                }
                else
                {
                    symbolSuccess = 0;
                    fprintf(parse_Output, "Symbol Expected\n");
                    return 0;
                }
            }
        }
        else
        {
            symbolSuccess = 0;
            fprintf(parse_Output, "Symbol Expected\n");
            return 0;
        }
    }
    else if (strcmp(nextToken, "LeftParen") == 0) // (EXP)
    {
        gettoken(currentScanFile);
        if (Exp())
        {
            if (strcmp(nextToken, "RightParen") == 0)
            {
                gettoken(currentScanFile);
                return 1;
            }
            else
            {
                symbolSuccess = 0;
                fprintf(parse_Output, "Symbol Expected\n");
                return 0;
            }
        }
    }
    else
    {
        symbolSuccess = 0;
        fprintf(parse_Output, "Symbol Expected\n");
        return 0;
    }
}

// Cnd production
int Cnd()
{
    if (Exp()) // -> Exp Rel Exp
    {
        if (Rel())
        {
            gettoken(currentScanFile);

            if (Exp())
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            fprintf(parse_Output, "Missing Relational Operator\n");
            return 0;
        }
    }
    else
    {
        return 0;
    }
}

// Rel production
int Rel()
{
    if(strcmp(nextToken, "LessThan") == 0){ return 1; }
    else if(strcmp(nextToken, "Equal") == 0){ return 1; }
    else if(strcmp(nextToken, "GreaterThan") == 0){ return 1; }
    else if(strcmp(nextToken, "GTEqual") == 0){ return 1; }
    else if(strcmp(nextToken, "NotEqual") == 0){ return 1; }
    else if(strcmp(nextToken, "LTEqual") == 0){ return 1; }
    else { 
        return 0;
     }
}
